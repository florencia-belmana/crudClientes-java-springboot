package com.coderhouse.coderhouse.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table( name = "CLIENTE")
public class Cliente {

    //Creacion de vars.

    @Column(name = "DNI")
    @Id
    private Long dni;
    @Column(name = "NOMBRE")
    private String nombre;
    @Column(name = "APELLIDO")
    private String apellido;
    @Column(name = "FECHANACIMIENTO")
    private Long fechaNacimiento;

    //CONSTRUCTORES
    //Vacio x Entity.
    public Cliente() {
    }
    //constructor con params.
    public Cliente(Long dni, String nombre, String apellido, Long fechaNacimiento) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
    }

    //GETTERS & SETTERS.
    public Long getDni() {
        return dni;
    }

    public void setDni(Long dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Long getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Long fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }


    //Devolver JSON
    @Override
    public String toString() {
        return "Cliente{" +
                ", dni=" + dni +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", dni=" + dni +
                /*  ", edad=" + edad + */
                '}';
    }

}

