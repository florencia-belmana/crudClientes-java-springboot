package com.coderhouse.coderhouse.controller;

import com.coderhouse.coderhouse.model.Cliente;
import com.coderhouse.coderhouse.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("coderhouse/clientes")
@RestController

public class ClienteController {

   @Autowired
   private ClienteService clienteService;


   //metodo para listar todos los clientes
    @GetMapping("/all")
   public List<Cliente> buscarTodosLosClientes(){
       return clienteService.buscarTodosLosClientes();
   }

   //metodo para calcular edad
    @GetMapping("/{}")
   public Cliente calcularEdad(@PathVariable Long fechaNacimiento){
       return clienteService.calcularEdad(fechaNacimiento);
   }
}
