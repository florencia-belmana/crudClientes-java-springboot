package com.coderhouse.coderhouse.service;

import com.coderhouse.coderhouse.model.Cliente;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;

public interface ClienteService {

    //Calcular edad.
    Cliente calcularEdad(Long fechaNacimiento);

    //Busco todos para mostrarlos
    List<Cliente> buscarTodosLosClientes();
}

