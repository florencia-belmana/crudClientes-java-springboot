package com.coderhouse.coderhouse.service;

import com.coderhouse.coderhouse.model.Cliente;
import com.coderhouse.coderhouse.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*import java.time.LocalDate;*/
/*import java.time.Period;*/
/*import java.time.format.DateTimeFormatter;*/
import java.util.List;

@Service
public class ClienteServiceImpl implements ClienteService{

    @Autowired
    private ClienteRepository repository;

    @Override
    public Cliente calcularEdad(Long fechaNacimiento) {
        return repository.findById(fechaNacimiento).orElse(null);
    }

    @Override
    public List<Cliente> buscarTodosLosClientes() {
        return repository.findAll();
    }


    /*
    @Override
    DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    LocalDate fechaNacimiento = LocalDate.parse("15/08/1993", fmt);
    LocalDate ahora = LocalDate.now();

    Period periodo = Period.between(fechaNacimiento, ahora);
    System.out.println("Tu edad es: %s años, %s meses y %s días",
        periodo.getYears(), periodo.getMonths(), periodo.getDays());*/
}
