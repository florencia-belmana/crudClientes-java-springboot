INSERT INTO CLIENTE

(nombre, apellido, dni, edad)values
( 'Juan', 'Perez', 12345678, 48),
('Azucena', 'García', 23456789 ,29),
('Ibrian', 'Festorazzi', 23966789 ,31),
('Serafin' , 'Lopez', 34567890, 24);