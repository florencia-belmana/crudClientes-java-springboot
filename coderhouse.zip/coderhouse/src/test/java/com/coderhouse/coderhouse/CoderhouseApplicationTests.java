package com.coderhouse.coderhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoderhouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
